package com.lcwd.bracketbuilder;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BracketBuilderApplicationTests {

	@Test
	void contextLoads() {
	}

}
