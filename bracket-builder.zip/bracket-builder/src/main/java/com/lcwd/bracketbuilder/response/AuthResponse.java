package com.lcwd.bracketbuilder.response;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class AuthResponse {


    private String data;
    private String message;

    public void setdata(String token) {
    }
}
